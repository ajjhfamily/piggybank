# Adafruit Keypad Library [![Build Status](https://travis-ci.org/adafruit/Adafruit_Keypad.svg?branch=master)](https://travis-ci.org/adafruit/Adafruit_Keypad)

<img src="https://cdn-shop.adafruit.com/970x728/4020-04.jpg" height="300"/>

This is a library for using diode multiplexed keypads with GPIO pins on Arduino.

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by Dean Miller for Adafruit Industries.
MIT license, all text above must be included in any redistribution
